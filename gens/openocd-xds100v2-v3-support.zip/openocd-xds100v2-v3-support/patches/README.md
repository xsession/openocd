# Patch usage

`0001-ftdi-initial-signal.patch` contains the core OpenOCD source change in a
review-friendly unified diff. Because the xsession fork can move with upstream,
the recommended installer is the idempotent semantic patcher:

```console
python3 scripts/apply_xds100_support.py /path/to/openocd
```

It validates exact source anchors, applies the same source change, installs the
complete interface/configuration overlay, and updates known udev rule files.

For a close OpenOCD checkout, the source-only patch can be reviewed or applied
manually:

```console
git apply --check patches/0001-ftdi-initial-signal.patch
git apply patches/0001-ftdi-initial-signal.patch
```

Then copy the files from `overlay/` to the corresponding paths in the OpenOCD
checkout, or use the semantic patcher to do that automatically.
